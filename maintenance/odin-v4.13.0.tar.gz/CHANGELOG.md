# Changelog

All notable changes to Odin are recorded here, written for operators rather than
from commit subjects. The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).
Each GitHub release body is the matching section of this file.

## [Unreleased]

## [4.13.0] - 2026-10-01

### Upgrade notes

- **The command governor rates more dangerous command forms critical.** It now recognizes more forms of remote-script
  execution, uploads of sensitive local files to outside hosts, and requests to cloud instance-metadata endpoints.
  Installs with `governor.admin_can_override: true` still let admins run them, with the existing warning and audit
  label. On other installs, and for non-admin users, they are blocked. No command is rated or blocked lower than in
  4.12.0, and ordinary private and LAN uploads are unaffected.
- **`/api/processes` entries gain two fields:** `effective_shell` and `termination_reason`. Both are always present
  and are null when the value was not recorded. A normal exit has no termination reason. The change is additive.

### Added

- **Skills page: an Enable/Disable control on every skill card.**
  - The card shows whether a skill is enabled or disabled.
  - A disabled skill keeps View Code and Edit, and Test stays disabled until it is enabled again.
  - The change takes effect immediately in the tool catalog and the prompt.
- **Skills that fail to load can be deleted from the WebUI.** Their card shows the load error once, with a Delete
  button and no code or test controls. The model-facing `delete_skill` tool is unchanged.
- **The Processes page and API show each job's shell and, when recorded, how it ended.** `manage_process` poll output
  includes the shell when it is known.

### Changed

- **Codex tool-call history replays the model's own arguments.**
  - Within a turn, Odin sends back the exact argument text the model emitted for its earlier tool calls, instead of
    the normalized form. Before, the model could see its own calls contradict the tool schema (for example
    `http_probe` headers sent as a list and replayed as a map) and retry them.
  - The text is held in memory only (up to 256 KiB per call) and is never stored.
  - Execution, audit, storage and other providers are unchanged. A turn resumed after a restart replays the
    normalized form, as before.
- **Command classification is structural as well as textual.** The audit label and the enforcement decision come from
  the same assessment. Repeated classifications of the same command are cached, and large commands classify faster
  than in 4.12.0.
- **Tool calls returned together are ordered as the model emitted them.**

### Fixed

- **`apply_patch` no longer fails with "Argument list too long" on larger patches.**
  - Before, roughly 40–48 KiB of patch text exceeded Linux's per-argument limit, locally and on remote hosts.
  - A command over that limit is now sent compressed and unpacked by the host's `python3`.
  - A command that is still too large is refused before it runs, with nothing written.
  - Smaller patches send exactly the same command as before.
- **Skills page:** a failed skill's error no longer appears twice, and the View Code button only shows when there is
  code.

## [4.12.0] - 2026-10-01

### Upgrade notes

- **Local commands now run under bash by default.** The new `tools.command_shell` setting (`auto`, `bash` or `sh`,
  default `auto`) runs raw model- and skill-written local commands under bash when it is installed. Set
  `tools.command_shell: sh` to return to `/bin/sh` at once; new commands pick up the change without a restart. Review
  persisted automation (schedules, workflow steps, skill `run_on_host` literals) for dash-specific syntax before
  upgrading. Details are under Changed.
- **The usage store migrates from schema 3 to 4 on first start, one way.** Rolling back to 4.11.0 or earlier switches
  usage statistics off (the store itself is left untouched) until you upgrade again. Back up `data/usage/` before
  upgrading if you may roll back.
- **Open-file headroom.** The packaged `odin.service` already sets `LimitNOFILE=65536`; installs that run Odin from
  their own unit should use equivalent headroom, for example in a drop-in. New in this release, the `open_files`
  health component reports descriptor use against the soft limit and warns above 70%.
- **The system prompt lists only usable skills.** Disabled skills and skill files that fail to load are no longer
  listed in the prompt. `list_skills`, `/api/skills` and the WebUI still show every skill with its status.

### Added

- **"Stay logged in" survives restarts.** Ticked WebUI sessions can survive restarts for up to 30 days, subject to the
  configured inactivity timeout. The private session records (`data/web_sessions.json` and a key file, both 0600)
  store hashed session ids, identity and source metadata, timestamps, and either an HMAC credential digest or a
  dynamic-token issuer fingerprint; no bearer credentials are stored. Unticked sessions stay in memory only, and token
  rotation, revocation or logout still end sessions.
- **Browser waits are configurable per call.** `browser_click`, `browser_fill` and `browser_read_page` accept an
  optional `wait_timeout_seconds` (default 10 seconds), clamped to the new `browser.max_wait_timeout_seconds` (default
  and hard maximum 60).
- **Reasoning tokens are recorded** for Codex and OpenAI-compatible providers when the provider reports them, in usage
  accounting and generation records, and shown beside output tokens on the Usage page. Generations recorded before the
  upgrade show as unknown.
- **Listings show what the model needs.** `list_skills` shows each skill's status (loaded, disabled or failed to load)
  (#631), and `list_agents` shows each agent's model and effort.
- **An `open_files` health component** (see Upgrade notes).

### Changed

- Raw local model/skill commands and new background jobs now default to deterministic, non-login
  bash when available (`tools.command_shell: auto`), otherwise sh. The effective local shell appears in
  the tool descriptions and is kept in background process records; successful command and skill output is unchanged,
  with no shell footer. Explicit `bash` refuses before dispatch if unavailable.
  Set `tools.command_shell: sh` for immediate compatibility rollback. New jobs
  alone use a changed setting; retained records and running-job cleanup keep
  their original shell. Remote execution and explicit script interpreters are
  unchanged. Code-built internal commands, file/patch transports, script wrappers,
  HTTP wrappers and non-command validation probes stay `/bin/sh` without shell
  annotations. Workflows, schedules, delegated tasks, loops and agents inherit
  the setting only through raw command tools. Review persisted automation for
  dash-specific syntax before upgrade.
- Under bash, `echo` no longer interprets backslash escapes by default and
  `echo -e` is honoured; use `printf` for escapes. Unquoted `{a,b}` and numeric ranges such as
  `{1..5}` expand, and `$'…'` decodes ANSI-C escapes. Glob match order follows the locale
  (for example `LANG=en_US.UTF-8`), not raw byte order. A failed builtin's `$?`
  can differ: failed `cd` returns 2 under dash and 1 under bash. Error wording
  uses `bash: line 1:` rather than `/bin/sh: 1:`. `tools.command_shell: sh`
  remains the compatibility rollback.
- The descriptions of `run_command`, `run_command_multi`, `manage_process` and `validate_action` name the effective
  local shell in one sentence. `manage_process` also says that remote background jobs run under `/bin/sh`, and the
  others that remote commands use the remote account's login shell.
- Local command failures report what happened. Timeouts read `Command timed out (exit N)`, with the signal and
  termination reason when known, and local `validate_action` command checks report `timed out after Ns`. Remote
  command wording is unchanged.
- `parse_time` accepts the named clocks `noon` and `midnight`, and a clock with a day-part phrase such as
  `8 tonight`, `this evening at 8` or `11 in the morning`, including supported day words and explicit zones
  (`8 tonight ET`). A day-part phrase alone does not choose a time. `midnight` means the end of the selected day, so
  `tomorrow at midnight` is 00:00 on the day after tomorrow. Contradictions such as `8am tonight` or
  `20:00 in the morning` are rejected; 4.11.0 accepted some of them with the wrong time.
- The `create_skill` description states the full module contract (a `SKILL_DEFINITION` dict and
  `async def execute(inp, context)`) with a minimal example, instead of pointing at template files that are not
  shipped (#630).

### Fixed

- WebUI tabs return to the sign-in screen when their session ends, for example after a restart, instead of staying on
  "Unauthorized/Offline" (#633).
- Retained process output no longer holds an open file descriptor per job for 24 hours (#634).
- Changing, regenerating or deleting one API token no longer signs out every other API-token WebUI session, a
  regression since 4.11.0. A token's own change still ends its sessions and closes its WebSockets.
- "Test skill" in the WebUI runs as the signed-in user, with that user's host access and tier. It previously ran with
  no identity, so every host call was refused.
- Live Tail reads only the end of the audit log, off the event loop, instead of reading the whole file on every
  Logs-page connect.
- Removing a host-access entry is audited with the actor, the user id and the previous entry. Removing an absent entry
  returns 404 and writes nothing.
- `web_search` timeouts say the search timed out and after how long, and no error renders an empty message.
- Loop history no longer repeats the iteration prefix (`Iteration 2: Iteration 2: …`).
- The local command supervisor no longer loses ownership of a job when a process vanishes during descendant
  discovery, and it detects exits immediately instead of on its next poll.
- The command governor recognizes more bash syntax, including ANSI-C quoting (`$'…'`), brace expansion and process
  substitution. It remains a conservative classifier, not a full shell interpreter.
- The WebUI skills page labels skill files that fail to load ("failed to load", with the error) and hides the controls
  that cannot work for them.
- Native keyboard-focus tests are deterministic (#632).

## [4.11.0] - 2026-09-30

### Fixed

- Successful SSH or executor recovery retries now
  report success while retaining uncertainty about earlier dispatches. Emergency
  input release clears an `unknown_release` fence when the guardian ledger says
  released, with fresh consent still required; native target-continuity loss
  remains quarantined. Verified-empty remote process groups report clean exit
  or kill with an explicit process-group-only containment caveat, not a blanket
  unknown outcome. Unchanged durable legacy PDF imports reuse their basename
  source; changed or unverifiable legacy content requires an explicit source
  choice because historical imports did not retain originating URLs. Removed
  `grafana_alerts` config is silently tolerated, secured HTTP exceptions are
  re-raised rather than returned, and overview docs link authoritative inventory
  sources instead of stale totals and list all four computer-use handoffs.
- Missing local process handles no longer count as proof that descendants have
  exited. Unsettled records retain their host authority and block clean shutdown;
  restored read-only evidence does not attempt to terminate an old execution.
  A group-empty scan also stays unproven until the leader has been reaped, so a
  reap timeout or cancellation cannot publish a premature cleanup verdict.
- Scheduler reservations are revalidated against current identity and pause
  state before execution; malformed trigger filters no longer block valid
  schedules. Empty trigger subscriptions are rejected. Retry timestamps reflect
  the retry, clock-only reminders handle both daylight-saving fall-back
  instants, invalid 12-hour values are rejected, and 24-hour clocks may precede
  the day text. `parse_time` accepts `AM`/`PM` in any case after a space (such as
  `2:30 PM`, which 4.9.1 and 4.10.0 rejected as a timezone abbreviation) and
  dotted `a.m.`/`p.m.` markers, and rejects a bare 24-hour clock followed by
  words it cannot interpret instead of ignoring them. Workflow conditions run after empty successful output, scheduled
  native errors remain failures, deferred host defaults follow each tool's
  contract, nested skill inputs are checked against the selected skill schema,
  and `update_schedule` exposes workflow condition/failure-policy fields.
- Provider-declared incomplete Codex and Ollama responses are marked incomplete
  and failed without discarding partial text or retrying it away; complete long
  replies remain unchanged. Empty native Ollama output is an error. DeepSeek
  overflow classification applies to production-created clients, schema
  sanitization preserves keyword-named parameters, and bounded auxiliary
  qualification accepts expected truncated/empty probe responses. Compatible
  and Ollama accounting uses response-scoped model/token facts; canonical model
  selection reaches covered requests, borrowed auxiliary wrappers survive
  reloads, and one settled half-open circuit-breaker probe is admitted at a
  time. OpenRouter fallback limits account for every permitted route.
- Codex credential publication uses exclusive private temporary files and
  completes partial writes before replacing the destination. Manual login
  merges accounts rather than replacing the pool; failed merged writes preserve
  existing accounts. Refresh, administration and quota checks are fenced against
  account deletion, reordering, re-authentication and reloads. Authentication
  failure rotates away from a manually selected account, and displayed account
  indexes continue to identify the intended valid record when malformed entries
  are present.
- Tool execution preserves outcome uncertainty after ambiguous dispatch, inner
  timeouts and later retries; output text cannot forge execution metadata.
  Typed tool failures survive native, deferred and validation routes, retry exit
  status remains authoritative, `max_retries=0` still makes the initial SSH
  attempt, and streaming handles long lines and reaps children when consumers
  fail. Validation regexes run with a deadline off the event loop; numeric zero
  compares correctly, refused probes are not reported as executed, invalid HTTP
  probes acquire no host lease, and truncation/risk metadata tracks delivery and
  shared action-aware classification.
- Skills persist activation before publication; editing disabled skills keeps
  them disabled, and edit/delete operations target the loaded artifact.
  Requirements honor installed versions and extras, accept valid compound PEP
  508 constraints and reject unsafe forms. Skill host commands and selected
  skill invocation pass inherited admission and current-scope checks; validation
  uses requester tier and effective host. `systemctl` global options no longer
  hide lifecycle verbs from risk classification. Unsupported generic
  `SkillContext` calls are refused, its helper documentation distinguishes
  synchronous from asynchronous methods, and authorized retained results keep
  the complete output.
- Scoped memory reads and deletes honor explicit personal/global scope while
  omitted scope retains its previous behavior. Empty compaction uses a
  deterministic nonempty fallback; history eligibility is applied before
  result limits, and cross-channel fallback selects globally newest eligible
  records. API execution sessions remain ephemeral, owned scoped searches are
  available to their owner, and foreign scopes are rejected. PDF imports use URL
  identity by default; knowledge summaries compare authoritative snapshots,
  duplicate identifiers remain lossless, rolling summaries are recognized by
  APIs and metrics, cold embedding initialization leaves the event loop
  responsive, and hybrid fusion keeps the best-ranked payload.
- Learned entries with matching keys remain isolated by owner; edits and use
  extend expiry. Audit search/statistics and failure aggregates include retained
  rotations with stable coverage metadata, complete captured files and correctly
  framed diffs. Prompt totals include learned context. Prefix metrics identify
  unmeasured values instead of claiming upstream cache hits. Startup diagnostics
  validate knowledge database integrity and recognize static and dynamic API
  credentials without disclosure; tokenless HTTP readiness no longer depends
  on an unconfigured Discord gateway. Usage ingestion releases its lock after
  database-open failures, and resource counts use the configured session path.
- Computer recovery preserves incident lineage through emergency release,
  validates and archives qualified absence evidence, and reconciles only owned
  private evidence orphans. Clean resume publishes current recovery authority;
  status exposes bounded native recovery guidance without private handles.
  Expired inventory proofs and settled terminal caches are retired safely.
  Proven pre-input refusals restore eligible observations without weakening
  held-input or unknown-release fences, and isolated X11 preflight requires
  privilege only when configured to use it.
- Background process admission includes pending starts and unresolved owned
  executions. Process lifetimes bind exact generations; persistence failures
  trigger cleanup without abandoning lifecycle ownership, local leader exit is
  not completion until descendants settle, and remote cleanup failures remain
  explicitly unknown. Verified-empty remote process groups settle with a
  process-group-only caveat, not a claim that escaped descendants ended.
  Completed remote evidence retains its bounded retrieval deadline even when
  execution cleanup remains unknown. Explicit local termination claims success
  only after owned cleanup is proved. Remote stdin reports accepted bytes after
  partial writes, and cancelled SSH master
  closure retains its ownership handle for retry. Host-key mismatch quarantine
  survives unrelated inventory publication, host management publication is
  serialized, and CA enrollment verifies signing authorities and endpoint
  principals. `apply_patch` preserves untouched text boundaries, rejects
  nonregular files without blocking on FIFO open, and closes snapshots on
  semantic rejection.
- HTTP browser sessions are bound to credential origin and generation, expire
  when the originating credential is revoked or rotated, and lose anonymous
  development authority when authentication is enabled. Invalid static token
  tiers are refused rather than treated as administrator. Supported WebSocket
  authentication carriers use consistent credential precedence, login handles
  malformed JSON shapes, security headers cover raised HTTP responses, expired
  sessions are retired, and reconnecting WebSockets remain subject to chat rate
  limits. Process termination reports acknowledged outcomes. Failed self-update
  paths restore operator files. Observed WebSocket credential revocation is
  terminal for that transport, even if an old credential is later restored;
  schema-aliased mapping fields survive partial configuration saves and reload.
- Autonomous loop failures count toward the configured consecutive-failure
  limit; terminal findings and natural completion timing are preserved. Outbound
  per-target admission is serialized and first events work on young hosts.
  Scheduled digest fallback stays within message limits, resume selects the
  requester's own preserved work, and buffered intake retains attachments.
  Authorized retrieval preserves complete truncated text/PDF evidence while
  retaining existing ownership, channel, quota and expiry fences. Generated
  images reject incomplete PNGs and report upload failures as failures.
- Incus deployment syntax and required UI assets, wheel model-hint data, CLI
  failure exit codes, browser dependencies in official install paths, and the
  Debian SSH-key default and safe default-only upgrades are corrected. Browser
  runtimes are provisioned and qualified without enabling new capabilities;
  custom SSH keys remain untouched. Compose now supports atomic config
  persistence and safely migrates an existing single-file config without
  overwriting a newer directory config, preserving setup state and listener
  consent during relocation. Portable `odin-server` and `odin-client` commands
  are provided for every package type with documented migration guidance;
  `odin` now runs the API client consistently on every install type and the
  server uses `odin-server`. Old server-style `odin` invocations with a config
  file, `-c`, `--config` or `--env-file` refuse to send a prompt, explain the
  new server command, and exit nonzero. Existing Python/source server scripts
  and units must switch to `odin-server`; Debian client usage is unchanged.
- Configuration migrations no longer require an adjacent write for no-op
  completion, and ceiling migration preserves a newer acknowledged edit.
  Retired Codex model migration now covers canonical agent selectors,
  allowlists and hints. Existing legacy model/effort pairs continue to load with
  a warning when invalid; saves validate the effective canonical selector.
  Partial config saves update submitted leaves only; deleting a mapping entry
  requires the explicit `{ "$delete": true }` marker, while JSON `null` remains
  a value. Provider enable routes parse booleans correctly. Nonpositive tool
  timeouts and negative archive caps are rejected on save and tolerated at
  startup with warnings and safe defaults; explicit zero archive retention
  still means retain nothing. Legacy Kimi timeout adaptation is bounded, and
  legacy configs with an absent provider keep their selected main model.
- The WebUI coalesces model-save intent, fences stale provider/MCP/operational
  page requests, keeps Discord identity fields consistent, and supports native
  keyboard activation of user selection. Skill source highlighting preserves
  original text. Paused Live Tail retains at most 2,000 raw records and reports
  drops; relative-time filters advance only while active. Live Tail uses bounded
  RE2 syntax, with unsupported lookaround/backreferences reported rather than
  silently accepted. Trace filtering precedes result limits, schedule forms can
  submit workflow steps, and missed terminal events become explicitly unknown
  history rather than fabricated running or successful results. Stream
  correlation uses unique backend registry IDs and full invocation attribution.
- Agent repetition detection hashes the full canonical scrubbed evidence before
  delivery, so changing envelope IDs, cursors or previews cannot bypass the
  guard. Cancellation before an agent coroutine starts is durably settled as a
  killed trajectory. The default Codex agent catalog honors authored model
  selection hints.
- Tool catalogs now hide browser and knowledge tools when their backends are
  disabled; email visibility follows executor-effective startup configuration,
  and dynamic computer tools participate in built-in disablement. MCP discovery
  isolates invalid header schemas to the affected tool, rejects terminal
  newlines in header values, and preserves structured results without repeating
  equivalent JSON summaries. SMTP acceptance is retained across QUIT cleanup
  failures, failed IMAP searches are not reported as empty results, and image
  validation decodes complete PNG data under size limits before delivery.
- Removed native monitoring references were audited through current source,
  tests and documentation tooling; generated API references remain to be
  regenerated after campaign integration. Generic internal resource/token/pool
  metrics and `/api/pools` remain; no native Prometheus formatter or endpoint is
  implied by this removal.

### Changed

- Upgrade notes:
  - `odin` is now the API client on every install type, and the server command is
    `odin-server`. Python, source and Compose scripts or units that started the
    server with `odin <config>`, `-c`, `--config` or `--env-file` must switch to
    `odin-server`; those old invocations now refuse, explain the new command and
    exit nonzero without sending a prompt. Debian installs and units that run
    `python -m src` are unaffected.
  - A static `web.api_tokens` entry whose `tier` is not `admin`, `user` or `guest`
    is now refused instead of being treated as an administrator. Correct the tier.
  - Browser sessions end when the API token that created them is revoked or
    regenerated.
  - Partial `PUT /api/config` saves change only submitted leaves. Deleting a
    mapping entry needs the explicit `{ "$delete": true }` marker.
  - SMTP and IMAP now verify certificates by default (see below).
- Documentation now describes setup-wizard restart behavior, supported
  WebSocket authentication, managed Hyprland first use, current provider/model
  capabilities, Codex refresh behavior, tool/loop iteration limits and retired
  model migration accurately. Stale inventory counts and removed monitoring
  claims were removed.
- SMTP and IMAP verify server certificates and hostnames by default; operators
  using self-signed mail servers must explicitly opt out. Accepted email is not
  misreported if QUIT cleanup fails, and IMAP search failures are not treated as
  proof of message absence.
- The WebUI prevents stale responses from replacing newer selections and
  operational state; live-tail retention/filtering is bounded, trace filtering
  precedes result limits, schedule forms submit workflow steps, and execution
  call correlation uses complete invocation identity. Host CA enrollment UI
  identifies the expected fingerprint as the signing CA fingerprint.

### Removed
- Removed native Grafana alert receiving, remediation, management routes and
  scheduler trigger publication, the unauthenticated Prometheus `/metrics`
  endpoint and its exporters, and `SkillContext.query_prometheus`. Existing
  configuration keys are tolerated and ignored; component checks remain on
  `/health`. Legacy removed-source schedules remain readable but inert.
  External operator-configured MCP integrations are unchanged. There was no
  native Loki integration to remove.

## [4.10.0] - 2026-09-29

### Added

- `gpt-6.1-sol` is available in native Codex selectors and agent catalogues
  between `gpt-6-astra` and `gpt-6-sol`. Its measured usable input budget is
  921,849 tokens; efforts `low` through `max` are supported, while `none` is
  rejected.

### Changed

- Fresh installs default the main Codex model to `gpt-6.1-sol` (including the
  configuration template and WebUI new-form fallback). Existing installs keep
  their persisted or compatibility-default model; auxiliary and agent defaults
  and retired-model migration remain unchanged.
- Agents that choose their own model now rank `gpt-6.1-sol` ahead of `gpt-6-sol`,
  which the agent catalogue describes as the balanced tier rather than the default.
- Upgrade note: to move an existing install onto the new model, pick `gpt-6.1-sol`
  as the main model on the WebUI LLM page, and add it to the agent auto-model
  allowlist if you use one. Choose any effort except `none`.

## [4.9.1] - 2026-09-28

### Fixed

- `parse_time` honours a timezone written at the end of the expression
  instead of silently ignoring it. IANA zones (for example
  `America/New_York` or `Europe/London`), `EST`/`ET` and "New York time"
  are supported. Ambiguous or unknown zones (for example `PST`) are
  rejected with a clear error instead of being interpreted in the bot
  timezone. Expressions without a zone still use the configured `timezone`.
- `validate_action` `log_absent` and `log_present` checks no longer match
  their own invocation. Odin logs every tool call, including the check's
  pattern, so a check against Odin's own log (or the whole journal) could
  pass or fail on that line alone. `log_present` could report an event that
  never happened, and `log_absent` could fail on a pattern that never
  occurred. The check now ignores its own tool-call line.

### Changed

- `generate_image` returns the posted image's Discord attachment URL, so the
  model can inspect or reuse the image it just made in the same turn (for
  example with `analyze_image`). Only HTTPS URLs on Discord's attachment CDN
  are returned.

## [4.9.0] - 2026-09-28

### Fixed

- Runaway Codex generations are fixed. Since 4.2.0 every Codex tool was sent
  with `strict: false`, and GPT-6 Sol and Luna (occasionally older models)
  could fail to finish a tool call's arguments: the model kept writing inside
  the call, often as whitespace or its own internal text in an extra argument
  key. The generation then streamed until OpenAI cut it at about 15 minutes
  or an agent's 900-second limit retried it, or it finished with a garbage
  argument key that was dispatched. Codex tool calls are constrained to their
  schemas again. In replays of real failing agent contexts the 4.8.0
  behaviour degenerated in 10 of 20 attempts and this release in 0 of 20.
- Codex models can no longer invent tool arguments (for example a `timeout`
  on `run_command`) that were accepted and silently ignored.

### Changed

- Codex tool calls use strict (schema-constrained) function calling again.
  Optional arguments stay optional: the model sends `null` for "not
  provided" and Odin removes it before the tool runs, while explicit `false`,
  `0` and empty strings are kept.
- Codex tool-call arguments are validated against the tool's schema before
  anything runs. An invalid call returns an ordinary tool error to the model
  and nothing is executed.
- `http_probe` headers are a list of `{name, value}` entries, and header
  names that differ only in case are rejected. Callers that pass a
  name-to-value object (stored schedules, workflows, skills) keep working.
- `validate_action` check `expected` values must be an integer, a string, or
  a list of integers or strings (for example `[200, 204]`).
- Webhook triggers for `schedule_task` and `update_schedule` accept exactly
  `source`, `event`, `repo` and `alert_name`, in any combination, matched
  together.
- For Codex models, the `tool_input` of schedules, workflow steps and
  delegated tasks, and the `input` of `invoke_skill`, are sent as JSON text.
  Odin decodes it once and validates it against the target tool before
  storing or running it; placeholders such as `{var.name}` are checked after
  substitution. Stored schedules and workflows keep their format, and other
  providers still send objects.
- Skills and MCP tools: an explicitly closed input schema
  (`"additionalProperties": false`) is called with structured strict
  arguments. An open schema (the JSON Schema default) is called with one
  JSON-text argument, which Odin decodes and validates against the original
  schema, so what the skill receives is unchanged. A schema Odin cannot adapt
  stays non-strict and is logged. Skill authors who want structured arguments
  can add `"additionalProperties": false` to their input schema.
- `computer_act` is sent to Codex as a closed wrapper around one operation.
  The full action contract is still checked before any input; constraints
  the strict schema cannot express are enforced by that check.
- Each tool's strictness is logged once per schema version, and a built-in
  tool that the server does not confirm as strict logs a warning.

### Upgrade notes

- No configuration changes. Existing schedules, workflows, skills and MCP
  servers keep working. OpenAI-compatible and Ollama providers are unchanged
  apart from the tool-schema updates above.

## [4.8.0] - 2026-09-26

### Changed

- The WebUI LLM page lists only enabled providers' models. With the compatible
  provider and Ollama disabled, the Main, Agent and Auxiliary selectors show
  plain Codex options without group headers or the catalogue search, and the
  Agent auto-selection allowlist stays available. A saved model from a
  disabled provider stays visible as one labelled `Configured: … (provider
  disabled)` option with a warning; disabling a provider that a role uses
  warns before saving and never changes configuration; allowlist entries of a
  disabled provider stay in the ranked list as `Excluded: provider disabled`
  with configured and effective counts. With providers enabled the page
  behaves as before.
- Compatible and OpenRouter models budget chat, loop and agent history against
  the output each request actually reserves (the profile's maximum output,
  capped at 32,768 tokens), the same figure agent eligibility already used.
  Long tool-using turns keep more history before summarizing (DeepSeek V4 at
  the default 75%: 491,520 to 761,856 working tokens), so those turns send
  more input tokens per request; models whose declared output nearly equals
  their context window no longer run with no history budget and no overflow
  rescue. An agent whose compatible provider rejects a payload already below
  the provider-reported window now compacts instead of re-sending it. Codex is
  unchanged. To retain the previous smaller compatible working set, lower
  `openai_compatible.context_utilization` (about 48 for DeepSeek V4's previous
  491,520 tokens).
- One-time check, workflow and webhook schedules interrupted by a restart are
  now paused as inert rather than run again from the beginning. Their reason
  is shown to operators; set a new `run_at` to re-arm after checking effects.
  Reminders and digests still replay, and recurring schedules are unchanged.
  No action is required on upgrade.
- Documented webhook success, partial-delivery and retry behaviour for
  scheduled webhook actions and inbound webhooks.
- History search finds archived conversation summaries again; the first start
  after upgrading indexes existing archives in the background. Expect the
  session and full-text databases to grow during this one-time migration.

### Fixed

- OpenRouter models listed from the cached catalogue on the LLM page show the
  server's availability and agent-eligibility verdict instead of always
  appearing available.
- Computer-use requests refused before any input (unknown source IDs, export
  on an attached desktop, Hyprland target discovery failures, and stale or
  unknown session references) now report `not_dispatched` with a safe next
  step instead of unknown-outcome RELEASE-ALL guidance. Such refusals no longer
  cancel a running session, including another session in the same channel.
  Successful computer calls are audited with a success reason code rather
  than `computer_rejected`.
- `email_send` reports recipients the mail server refused (To, CC or BCC)
  instead of claiming the message went to everyone; a partial send is reported,
  never retried.
- `email_read` no longer shows a text attachment as the message body, and its
  attachment list follows the MIME disposition (any capitalisation) instead of
  a text match.
- `http_probe` sends request bodies starting with `@` literally instead of
  uploading a file, and rejects header names starting with `@`. Such bodies
  require curl 7.43 or newer on the probing host.
- `validate_action` process checks no longer find their own command instead of
  the target process; a matching ancestor still counts. Missing `pgrep` and
  unusable patterns now report errors rather than false health.
- `validate_action` log checks report an error when the journal cannot be read
  or is only partly readable instead of claiming it is clean. Invalid patterns
  report errors and journalctl notices no longer count as log lines. Operators
  whose service user lacks journal access must grant it (for example via the
  `systemd-journal` group) before relying on these checks.
- `validate_action` HTTP checks accept explicitly expected 4xx/5xx statuses;
  connection failures and timeouts never count as a received status.
- The release workflow rejects tags that are not `vMAJOR.MINOR.PATCH` before
  touching package metadata, and passes a validated version to shell steps as
  data rather than embedding tag text in a command.
- Documentation and `scripts/monitor.sh` now point to standard output and the
  systemd journal rather than a log file Odin never writes. Fresh packages since
  v4.0.0 start immediately in loopback-only bootstrap mode; the computer-use
  handoff and install pages now say so.
- Logging in to the WebUI without **Stay logged in** now replaces an older
  saved login, so reloading after a restart retains the new session instead of
  returning to the login screen. A persistent login also clears the tab's old
  session-only credential.
- Compatible endpoints configured for GLM preserved thinking now count replayed
  reasoning when sizing context, so history is summarized before it overflows
  and overflow recovery no longer claims a fit while that reasoning is still
  sent; replayed reasoning is never shortened or edited.
- Verify integrity checks every retained rotated audit file, not only the active
  one, and lists each file's result (verified, predates signing, break at line N,
  unreadable, missing); files are streamed in a worker thread instead of read into
  memory.
- A tool that hit its time limit no longer lets the turn continue when its
  ledger record could not be saved; the turn stops with an error, as every
  other ledger write failure already does.
- Resuming interrupted work no longer leaves a tool call unanswered, or answers
  it with an earlier call's result, when a model provider reuses tool-call IDs
  across replies. Agents also accept IDs reused across separate replies while
  still refusing duplicates within one reply.
- Scheduled digests report disk and memory again. They run under the schedule's
  identity (the creator, or the `scheduler` system identity) and list hosts they
  cannot reach as collection failures.
- Grafana-triggered schedules with an alert name now match any alert in a
  notification, not just the first; each schedule still runs once per
  notification.
- Browser tool descriptions state that every call starts a fresh browser session:
  `browser_click` no longer suggests reading the clicked page with a later
  `browser_read_page`, `browser_fill` points to `submit=true`, and
  `browser_evaluate` notes that navigation it starts is not awaited. Browser
  behaviour is unchanged.
- Compressed tool history labels failed calls with a short reason (for example
  `run_command→ERR (blocked)`, `→ERR (timed out)` or `→ERR (disallowed host)`)
  instead of incorrectly marking these failures OK; Recent Actions marks
  failed calls ERROR. Successful calls with explicit outcome metadata remain OK.
- Long replies split around code blocks keep their formatting: text after a
  block no longer shows as code, no message ends with an empty code block, and
  a split with a long language tag no longer creates an over-limit message.
  Truncated workflow and loop posts close open code blocks before the marker.
- `parse_time` uses every part of an expression, including compound durations
  (`in 1 hour 30 minutes`), a day after a time (`5pm tomorrow`), a time after a
  weekday (`friday 3pm`), and `in 2 days at 9am`. Unused date or time words now
  return an error instead of silently scheduling the wrong time. Hours and
  minutes measure elapsed time across daylight-saving changes; days retain the
  local clock time.
- A cancelled knowledge, memory, list or learned write can no longer overwrite (or corrupt) a newer save that already succeeded.
- A failed knowledge ingest no longer leaves search hits for a document that was not stored or blocks that name; leftovers from earlier failures are removed at startup.
- Knowledge ingest reports failure when its version record cannot be saved, and re-ingesting the same content repairs a missing version snapshot.
- The Sessions page User ID filter now applies to every result source; summaries
  and index results that cannot be attributed are left out.

## [4.7.0] - 2026-09-24

### Added

- The System → Host Access page is redesigned. Each user row shows the Discord
  name, a Tier column, a compact host summary and the default host. An
  **Edit hosts** button on every row and on the Default Policy card opens a
  modal (full screen on phones) with search, a host checklist, an **All hosts**
  switch that also covers hosts added later, and a default-host picker that only
  offers allowed hosts. A search box filters the user list.
- Numeric Discord user IDs across the WebUI show the user's name and avatar,
  including users who no longer share a server with Odin (looked up by ID and
  cached through `GET /api/discord/users/{user_id}`).
- The Codex accounts table shows each account's quota windows as a bar that
  drains with usage, labelled with the remaining percentage and reset time. An
  idle-account check refreshes accounts that have not served a request recently.
- Malformed permission overrides can be repaired inline on Host Access with an
  explicitly chosen tier, and unusable API token entries can be removed from the
  API Tokens page. A removal is refused with 409 if the entry changed after it
  was displayed, and both actions are audited.

### Changed

- Codex failover is limit-aware: accounts known to be exhausted are skipped until
  their reported reset, and a 429 pauses an account until its reset. When every
  account is limited, the request still goes to the account whose limit resets
  first, and fresh quota data showing room clears a pause.
- Outbound webhooks may target private and homelab addresses, while cloud-metadata
  destinations remain blocked in every spelling. Redirects and DNS are validated
  at delivery, and webhook signatures are never forwarded to another origin.
- MCP calls keep the first response for a request ID on all transports; later
  responses are ignored with a payload-free warning. The handshake remains strict.
- The completion judge no longer imposes a 128-token output cap. Native Codex
  requests are unchanged; compatible and Ollama reasoning judges can use their
  normal output budget. Empty or ambiguous judge answers are logged as warnings.
- Knowledge ingestion splits unusually long words into bounded chunks. Existing
  documents are unchanged until re-ingested.

### Fixed

- Audit records for permission, token and host-access changes name the acting
  user instead of recording the WebUI session credential.
- Outbound webhook edits made in the API or WebUI persist across restarts. Each
  save changes only the affected entry in `config.yml`, keeps comments and
  `${VAR}` references, never writes resolved secrets, and refuses with 409 when
  the entry changed on disk. Configured per-target TLS verification and secret
  scrubbing settings now apply at startup.
- Basic-auth passwords in webhook URLs are masked in the webhook listing and in
  log lines, and the generic configuration route no longer accepts webhook
  targets.
- `/stop` removes its private deferred acknowledgement after Odin's public stop
  message is delivered, avoiding a duplicate private notification.
- Quota windows that report no duration are hidden and ignored by failover.
- Malformed permission overrides and API token records survive unrelated writes,
  with operator-visible diagnostics; existing effective tiers and token access
  are not changed.
- Trusted-proxy forwarding validates IP addresses, supports CIDR trust ranges,
  and walks the forwarded chain from the nearest proxy to prevent rate-limit
  bucket spoofing and inaccurate audit IPs.
- Concurrent knowledge ingests no longer bypass duplicate checks or add spurious
  versions; colliding chunk ID prefixes cannot overwrite chunks belonging to
  another source; whitespace-only paragraphs no longer produce empty chunks; and
  duplicate warnings are logged once.
- Usage coverage recovers from transient scan failures without a busy loop,
  detects oversized unfinished trajectory rows, and no longer drops rows at
  read-buffer boundaries.
- Computer-use audit and System Logs retain specific refusal reasons and input
  outcomes, including `target_changed_observe_again` and results that carry a
  screenshot, instead of collapsing them to a generic rejection.

### Removed

- Removed the System → Permissions page; per-user tiers are managed on Host
  Access. The permission API routes remain.
- Removed the unused standalone plan engine. The `python -m src.odin` plan
  runner is gone; remove any scripts or automation that invoke it when upgrading.
- Removed the Slack integration, its configuration fields, API routes and WebUI
  controls. Existing `slack:` configuration sections are ignored for upgrade
  compatibility; generic Slack-token redaction remains active.

## [4.6.0] - 2026-09-23

### Added

- Package upgrades now surface a versioned, mode-0600 configuration proposal and
  a private diff command without printing potentially secret YAML into install
  logs. Existing operator configuration is never rewritten.
- Release publishing now verifies the pinned nfpm package and requires a
  disposable-container `.deb` installation smoke before artifact upload.

### Changed

- Fresh installations select `gpt-6-sol` for main chat and `gpt-6-luna` for
  auxiliary work. Agents use an explicit per-spawn choice or configured agent
  model policy, with `gpt-6-sol` as the final fallback when no policy supplies
  a model.
  Existing unpinned installations retain their previous model defaults. Retired
  `gpt-5.5` and `gpt-5.3-codex-spark` selections migrate to `gpt-6-sol`.
- Agent spawn descriptions now rank GPT-6 Astra, Sol and Luna ahead of the
  previous generation and state the operator-approved tier guidance.
- Paused recurring schedules resume at the next defined interval, not by
  replaying a missed interval immediately.
- Knowledge re-ingestion distinguishes unchanged content and already-stored
  duplicates from storage failures.
- After tool use, a tool-less agent answer is checked for task completion. An
  incomplete answer gets up to three continuation nudges across the run; the
  next reply is accepted without another judge call. An answer still incomplete
  at the iteration cap fails rather than falsely completing. Classifier outages
  fail open. The completion judge runs on the auxiliary model for chat and agents.
- One-time schedules whose run time passes while paused are quarantined instead
  of firing when unpaused; setting a new run time re-arms them.
- X11 computer sessions can explicitly focus an application with
  `computer_act operation=focus`.
- Computer-use tools offer `inventory_targets` and its target fields only for
  an existing Hyprland session; other backends no longer advertise it.
- The computer-use tool description and operator guide state the
  alternate-input policy: a separately authorized input path may be evaluated
  when computer use is unavailable, but never used to route around an active
  safety guard or an unknown release.

### Fixed

- Force-revoking a host terminates its managed local processes; a process
  denied after startup is terminated or reported as an unverified outcome.
  Managed stdin follows host-specific strict command policy.
- Concurrent session-vector and FTS writes are serialized and rolled back on
  failure; trajectory reads no longer load entire daily partitions for
  bounded results.
- Package installation tightens the durable configuration file to mode 0600;
  the fresh template now matches the 12-hour WebUI session schema default.
- Auto-resumed turns balance Discord presence, and aborted tool streams are
  settled rather than leaving permanent active records.
- Tool timeout edits persist before updating live settings, apply to new calls
  only, and failures count toward tool-call attempts. Auxiliary fallback usage
  is recorded after the fallback actually executes.
- Bad persisted schedule timestamps quarantine only their own record. Skipped
  overlapping manual runs no longer claim to have run. Grafana remediation
  and cooldown state is periodically pruned after its semantic expiry.
- The Logs page Tool Activity preset now filters to tool records; overlapping
  search responses cannot replace newer results. Session checkbox keyboard
  selection no longer toggles the containing row.
- The Logs page Warnings+ preset shows WARNING, ERROR and CRITICAL records
  instead of WARNING only.
- Computer-use results and audit records carry the verified input outcome
  (`not_dispatched`, `released_verified` or `release_unknown`) separately from
  the failure reason. An action refused before any input is sent, such as one
  citing a superseded observation, now reports that nothing was dispatched and
  is safe to retry; RELEASE-ALL and operator intervention are reserved for an
  unverified release or an unknown outcome.

### Removed

- Removed the seven legacy Discord prefix-command cogs and disabled `!` prefix
  parsing. Scheduled-report reaction pagination remains registered.

## [4.5.0] - 2026-09-22

### Added

- Native Codex `gpt-6-sol` and `gpt-6-luna` selection for main, auxiliary, and
  agent models, including spawn catalogue guidance. Both accept all six reasoning
  efforts and use measured 921,799-token input-budget floors. Existing defaults
  are unchanged; selectors order GPT-6 Astra/Sol/Luna before the 5.6 family.

### Changed

- Discord page: the gateway card shows a state badge, and the token field follows
  the same pattern as the LLM credentials: a Configured pill, press Enter to
  replace, and a note saying whether the token uses the preferred environment
  storage or legacy storage. Global defaults render as compact aligned rows.
- `GET /api/discord/connection` adds `credential_usable` and
  `credential_preferred_storage`; the existing fields are unchanged for older
  clients. A refused connect now reads "no usable Discord credential".

### Fixed

- The Discord page's Runtime status always read "unknown" because it read the
  wrong response field. It now shows Connected, Connecting, Disconnected or
  Unavailable.
- An install whose working Discord token sat in legacy storage could not press
  Connect and was told no usable credential existed. Connect is now enabled by a
  usable token, and the page reports the storage format separately.

## [4.4.0] - 2026-09-21

### Added

- **Agents report what a generation is actually doing, not just that it is running.** A
  running agent now carries normalized progress telemetry: logical phase, physical request
  attempt and retry count, elapsed generation time, time since the last wire event, time since
  the last *substantive* delta, accumulated response size, tool-call counts, and how much
  partial work a retry discarded. `wait_for_agents` and `list_agents` both surface it, for
  example `generating for 85s; attempt 1; wire 0s ago; substantive 0s ago`. The separation of
  wire activity from substantive output is the point: a stream kept alive by keepalives while
  producing nothing is no longer indistinguishable from one making progress. The telemetry is
  machine-owned and agent-only - it never appends to an agent conversation, consumes an
  iteration, alters a response, exposes partial reasoning, or ends a turn, and the main chat
  path is unchanged.
- **Reasoning-token counts are captured** from compatible endpoints that report them, as a
  subset of output tokens rather than additional billed output.

### Changed

- **Compatible endpoints are now streamed.** `chat()` and `chat_with_tools()` share one SSE
  transport and accumulator. Delivery is still atomic - the response is streamed internally and
  returned only once terminal - so nothing about how a turn arrives has changed. Requests carry
  `stream_options.include_usage`, so usage, cache-token details and cost survive. A premature
  end of stream, a malformed terminal error, or a lost connection after partial data never
  returns that partial response as a completed turn.
- **UPGRADE NOTE: `openai_compatible.timeout` is migrated to two explicit fields.** A single
  ambiguous total is replaced by `request_timeout_seconds` (default 3600) and
  `stream_stall_timeout_seconds` (default 180), matching the shape the Codex transport has
  always used. An existing bare `timeout` becomes the stream-stall value while the total widens
  to 3600, and the migration is logged at startup stating exactly what it did. The rewrite is
  leaf-scoped and atomic: comments, placeholders, permissions, symlinks and unrelated keys are
  preserved, explicit new fields always win, and a concurrent newer edit is never overwritten.
  It runs once and is idempotent across restarts. No operator action is required.
- **An endpoint that cannot stream now fails qualification with a clear error** instead of
  silently falling back to a blind non-streaming request. The reload probe exercises the
  streaming path itself, so it cannot bless an endpoint whose production transport would not
  work.
- **Ordinary source edits no longer force an operational validation step.** `apply_patch` was
  treated as an operational mutation on every call, which injected a mandatory `validate_action`
  turn after each patch on the chat path. Measured over fifteen days that cost 1,848 calls, 98%
  of them occupying a dedicated model iteration, around 8.5% of all chat generations and roughly
  26 minutes of added latency per day - while about a quarter of the resulting checks fell in
  categories that had never once failed. Editing a file is not by itself an operational change.
  Operational command detection, `email_send`, and validation enforcement for genuine
  deployments and service changes are all unaffected, and `validate_action` remains available
  whenever it is actually warranted.
- **An OpenRouter provider pin now honours the fallback setting.** The "allow fallback away from
  the pin" control was overridden whenever a pin existed, so it had no effect in precisely the
  case it described. A pin can now prefer its provider while still falling back when that
  provider is unavailable.

### Fixed

- **Long compatible generations were being destroyed and silently retried.** The compatible
  transport applied its timeout as a whole-request total with no stall detection, so any
  generation needing longer than the configured window - routinely the case for a
  reasoning-heavy model over a large context - was cancelled, had all of its work discarded, and
  was retried from scratch up to four times. Nothing surfaced this to the caller, the agent, or
  the operator beyond one journal warning with an empty message. A single agent run lost 27 of
  44 minutes this way across four iterations while appearing merely slow. With streaming plus a
  stall bound, a generation producing 41,110 output tokens now completes without a single
  timeout.

## [4.3.0] - 2026-09-21

### Changed

- **An agent model must now be chosen explicitly when the agent model setting is
  `auto`.** `auto` means "choose per spawn", so `spawn_agent` marks `model` as required
  and no longer offers to fall back to a configured default. This is the behaviour
  change in this release: a caller that previously omitted the field now receives
  `model is required when agents.model is auto; choose an eligible model explicitly`.
  Nothing changes for the other two settings - a concrete agent model still runs exactly
  that model, and an unset (inherit) agent model still follows the main model. Operators
  who want inheritance should set a concrete model or leave the setting unset rather
  than `auto`. Existing scheduled workflows whose stored steps omit a model keep working:
  they resolve to an eligible candidate rather than failing.

### Fixed

- **The agent model allowlist could be bypassed completely by omitting the model.** The
  allowlist constrained only an explicit per-spawn selection. A spawn naming a
  non-allowlisted model was correctly refused, but a spawn naming no model at all skipped
  the check entirely and ran whatever the configuration resolved to. On an install whose
  allowlist held only fast, inexpensive models, agents could still run the main model on
  every spawn that left the field out - and the tool description actively invited that,
  ending with "Omit to use the configured agent model". The allowlist is now enforced on
  the resolved model, not just the requested one.
- **An inherited agent model read a configuration key that nothing had written since
  4.2.0.** Selecting the main model by model reference moved that choice to a new setting,
  but agent inheritance kept reading the older provider-scoped key. On any install whose
  operator changed the main model after upgrading, the two disagreed and agents silently
  inherited the stale value instead of the model actually in use. Both the schema and the
  runtime now resolve through one shared function.
- **A spawn could grant itself scheduled-workflow authority.** The marker distinguishing a
  scheduled dispatch was read from tool input, which the model supplies, so a spawn could
  include it and claim the higher scheduled iteration cap. Scheduled authority now comes
  from trusted execution context that a caller cannot forge.
- **Models from a disabled provider were still offered as agent candidates.** A disabled
  compatible or Ollama provider no longer contributes to the automatic candidate list.
- **A configuration that leaves no model able to run now says so.** When no candidate is
  available, `spawn_agent` is withheld from the catalogue and the reason is logged, rather
  than the tool being advertised with an unsatisfiable choice.
- **Configuration drift between spawn and execution is caught.** The eligibility check
  repeats when a generation is captured, so removing a model from the allowlist stops the
  next generation of an already-running agent from using it.

## [4.2.2] - 2026-09-21

### Fixed

- **The LLM configuration page no longer exhausts the API rate limit.** The live
  refresh added in 4.2.0 issued about ten requests every five seconds — roughly the
  entire 120-per-minute per-IP budget — so opening the agent model allowlist could
  return `rate limit exceeded`. It also re-fetched the OpenRouter catalogue (310 KB)
  and provider status (200 KB) on every tick. Polling now covers only live status and
  configuration, six requests every fifteen seconds; the model catalogues are
  near-static and load on mount and on an explicit refresh. The rate limit itself is
  unchanged — the page was wasteful, the limit was not wrong.


## [4.2.1] - 2026-09-21

### Fixed

- **Page-switching on scheduled report embeds works again.** The 4.1.0 cleanup that
  retired the generic Discord trigger cogs removed the only `on_raw_reaction_add`
  listener along with them, so control reactions on a paginated report were received
  by nothing. Reports still rendered, pagination state still persisted and the
  control reactions were still added — the pages simply never changed, and no error
  was logged. Pagination is now served by a dedicated listener rather than the
  retired generic trigger system, with a regression test that fails if nothing routes
  a reaction to the pagination service.


## [4.2.0] - 2026-09-20

Any OpenAI-compatible endpoint can now serve Odin, and agents can run on models
from different providers than the main thread. The Kimi-specific provider became
a generic compatible client, OpenRouter became a first-class preset with real
catalogue and routing support, and a neutral reasoning scale lets one control
drive effort across endpoints that each speak a different dialect.

### Added

- **Any OpenAI-compatible endpoint as a provider.** Supply a base URL, key and
  model; presets exist for DeepSeek, GLM/Z.AI, Qwen, DashScope, OpenAI, Moonshot
  and OpenRouter, and a custom endpoint works without one.
- **OpenRouter as a first-class preset**: browse the catalogue in the WebUI,
  derive a conservative per-model context profile from the endpoints that can
  actually serve it, pin a model to a specific provider, and rank routing
  preference while keeping vendor fallback.
- **Agent auto-model allowlist.** Choose exactly which models agents may select,
  in preference order, each with its own reasoning default. An empty allowlist
  keeps the previous behaviour.
- **Model selection hints.** Operator-written guidance for each allowlisted
  model, shown to Odin when it picks one, alongside measured facts (context,
  output ceiling, reasoning control).
- **A neutral reasoning scale** — `none`, `low`, `medium`, `high`, `xhigh`,
  `max` — translated to each endpoint's native vocabulary, so one control works
  across providers. Codex receives these natively; other endpoints receive their
  nearest supported equivalent.
- `openai_compatible.reasoning_effort` so a compatible **primary** model has a
  reasoning control, matching what agents already had.
- `ollama.num_ctx`, operator-visible, so prompts are no longer silently truncated
  to Ollama's default window.

### Changed

- **Per-model output caps.** Compatible requests derive their output budget from
  the model's profile instead of one global `max_tokens`, bounded at 32,768. The
  compatible **Max Tokens** field is gone from the WebUI because it no longer
  governs the request.
- **Iteration budgets by provider.** Codex agents keep 120 ordinary iterations;
  compatible agents receive the configured hard ceiling, because models that emit
  one short step per turn should not lose most of their budget to that style.
- `allow_fallbacks` now follows OpenRouter's own default of enabled, so a
  transient rate limit no longer kills an agent. An explicit per-model pin still
  forces fallbacks off.
- The LLM Config page refreshes while open, without overwriting a field you are
  editing, an open dialog, or an unsaved draft.
- Credential fields opt out of browser autofill and keep their styling if a
  browser ignores that.

### Fixed

- A truncated response is no longer reported as a completed agent. `finish_reason`
  of `length`, and a reply with neither text nor tool calls, now fail honestly and
  get one retry rather than presenting as an empty success.
- A Codex generation that consumes the iteration wall gets one fresh bounded
  retry instead of ending the agent.
- An unconfigured `temperature` is no longer sent, which had made every OpenAI
  reasoning model unroutable through OpenRouter's parameter filtering.
- `DeepSeekClient` accepts the per-model output cap argument; previously every
  request through the DeepSeek preset raised `TypeError`.
- Neutral reasoning no longer raises when an endpoint declares a vocabulary
  outside the Codex ladder.
- Profile derivation honours per-model pins, and reports limits from one real
  endpoint rather than combining the smallest context of one with the smallest
  output of another.
- Agent eligibility reserves the effective request cap instead of a model's
  theoretical maximum, which had excluded capable models.
- Saving OpenAI-compatible configuration works: `openrouter` and `model_profiles`
  serialize correctly, a failed client reload rolls back instead of reporting
  success, thinking mode persists, and a null `preset` no longer becomes the
  string `'None'` and block startup.
- The preset-to-dialect mapping lives in one place; one of its four copies had
  drifted and silently dropped reasoning control for DashScope.
- Health and startup diagnostics report the model actually serving rather than a
  configured fallback field.
- The OpenRouter catalogue route tolerates incomplete records instead of
  returning HTTP 500.

### Removed

- The Kimi-specific provider section, superseded by the generic compatible client.
  Existing `kimi:` configuration continues to load and is served by it.

### Upgrade notes

No action required. An existing `config.yml` loads unchanged; `ollama.num_ctx`
and `openai_compatible.reasoning_effort` take defaults. An install configured
only for Codex behaves exactly as before — the spawn surface, tool list and
effort tiers are byte-identical to 4.1.0.


### Added

- OpenAI-compatible endpoints can serve main, auxiliary, and agent generations
  independently of Codex chat. Agent Auto policy is a runtime-enforced ordered
  allowlist, and incompatible or under-budget models are not advertised.
- OpenRouter is a deliberate compatible-endpoint special case with catalogue
  profile auto-fill, authenticated per-route performance facts, per-model
  provider pinning, unified reasoning effort, real provider-reported cost, and
  measured cache-hit attribution by served upstream provider.

### Changed

- The LLM page uses one searchable grouped model catalogue and an OpenRouter
  list builder. Provider selection compares input/cache price, throughput,
  p50/p99 latency, quantization, tool support, and Odin's measured cache ratio
  instead of pretending the cheapest route is necessarily suitable for agents.

## [4.1.0] - 2026-09-18

A cleanup campaign: honest tool metadata, a timeout wall that finally honours
per-tool budgets, seven retired tools, and two authorization defects fixed.
Existing installations start unchanged — every removed configuration section is
tolerated silently and never rewritten — but capabilities are genuinely removed,
so read the upgrade notes.

### Upgrade notes

- **ComfyUI image generation is removed.** Only native OpenAI image generation
  remains, and it requires the Codex provider. `generate_image` no longer accepts
  `size`, `negative` or `model`: the native route selects its own dimensions and
  cannot honour those requests. Installations that generated exact-size images,
  used negative prompts, or selected a checkpoint lose those abilities. Existing
  `comfyui:` and `image.backend` configuration loads silently and is ignored.
- **Seven built-in tools are removed**: `git_ops`, `docker_ops`, `kubectl`,
  `terraform_ops`, `issue_tracker`, `spawn_loop_agents` and `collect_loop_agents`.
  The tool catalog is now 67 tools (20 core). Shell retains the underlying
  capability for the infrastructure wrappers; `issue_tracker` was unreachable in
  any case because no client was ever constructed.
- **Discord message and reaction schedule triggers are removed.** They were never
  delivered — nothing dispatched those events — while `schedule_task` advertised
  them and the scheduler accepted them, so a schedule could be created, report
  success and never fire. Stored schedules using them now load **paused and
  inert** with a stated reason rather than failing; give them valid timing to
  resume. Legacy `reaction_triggers:` and `message_triggers:` configuration loads
  silently.
- **Removing `git_ops` removes its push protections** — freshness preflight,
  exact source and destination binding, and a lease bound to the observed remote
  SHA. A command governor rule now blocks unconditional force pushes from the
  shell, but it is bounded shell recognition and does not reproduce those
  guarantees.

### Added

- A command governor rule blocking unconditional Git force pushes: `--force`,
  `-f`, bundled short flags and force-prefixed refspecs are refused, while
  `--force-with-lease` and `--force-if-includes` are not mistaken for them.
- Affordance metadata for `get_tool_output` and the three `computer_*` tools,
  which previously carried no footer at all, plus catalog decoration so
  dynamically appended computer definitions receive one.
- Corrupt authorization stores are preserved to timestamped sidecar backups
  instead of being overwritten.

### Changed

- **Tool affordance metadata is corrected across 36 entries.** The footers an
  assistant reads now match what the tools do. Notably `http_probe` and
  `validate_action` no longer claim `risk=none` while accepting arbitrary
  commands, the skill tools no longer claim `risk=medium` while loading caller
  Python, and tools that launch supervised work are classified by the work set in
  motion rather than by how quickly the call returns.
- Cost and latency may now be **omitted** for tools whose workload depends on the
  implementation they dispatch. An omitted dimension means unclassified — never
  free, instant or safe. The fallback for unknown tools assumes high risk.
- The Web listener exposure card reads durable authorization state, separates
  authorization from configured intent and the running socket, distinguishes
  pending from active exposure, and offers a reversible restrict-to-loopback path.

### Fixed

- **Per-tool timeouts are honoured on chat, autonomous loop, and agent paths.**
  Chat and loops previously used a single wall derived from
  `command_timeout_seconds`; agents received only the operator override map and
  therefore could not reach built-in budgets at all. The built-in 900-second
  budgets for `run_command` and `run_script` now reach every execution path, with
  the shared resolver's bounded recovery, dispatch, and settlement allowance.
- **Corrupt authorization stores no longer fail open or destroy the original.** A
  damaged `permissions.json` previously lost its overrides and fell back to the
  default tier, so a demoted user could read as an administrator; the next
  mutation then overwrote the corrupt file and the original was gone. Reads now
  degrade to the safest interpretation and mutations refuse with an explicit
  error.
- **A falsy requester identity no longer skips host access enforcement.** Host
  resolution and acquisition gated the check on a truthy requester, so work
  dispatched without one bypassed the fence entirely. Missing identity now fails
  closed; system work must present an explicit, host-scoped identity.

### Removed

- The ComfyUI image backend and its configuration.
- `git_ops`, `docker_ops`, `kubectl`, `terraform_ops`, `issue_tracker`,
  `spawn_loop_agents` and `collect_loop_agents`.
- The Discord message and reaction trigger cogs, their configuration sections,
  and the `discord_message` / `discord_reaction` schedule trigger sources.

## [4.0.0] - 2026-09-16

The onboarding, connection-lifecycle, Hyprland-foundations and model-retirement
campaign (PR #356). Existing installations keep working unchanged; read the
upgrade notes first because several defaults and behaviours change.

### Upgrade notes

- **Pre-existing installations start unchanged.** Source checkouts with `0775`
  directories, symlinked data directories, a working-directory `.env`, and legacy
  API token stores (symlinked, `0644`, or holding an invalid entry beside valid
  ones) all keep working. Group-writable ancestors log one diagnostic per
  directory and startup continues. No permission change or policy file is needed.
- **Automatic learning is now opt-in.** Configurations that omit
  `learning.enabled` load it off. An explicit `learning.enabled: true` stays on
  until an administrator switches it off in **Capabilities → Learned**. The
  switch applies live and governs both lesson generation and learned-context
  injection. Stored entries are retained. Deliberate memory (`memory_manage`,
  `memory.json`) is not affected.
- **Installations with no usable Web/API credential bind loopback only**, even
  if `web.host` is broader. Authenticated installations keep their configured
  listener. Widening a restricted installation requires the authenticated
  listener-consent procedure and an operator restart.
- **Retired models.** `gpt-5.5` and `gpt-5.3-codex-spark` are no longer
  selectable. Persisted selections migrate in memory to `gpt-5.6-terra` with a
  warning (an old image `outer_model` pin migrates to `gpt-6-astra`); the YAML is
  not rewritten. Explicit runtime requests for a retired model are rejected.
- **Gateway failure now stops the service.** If the attached Discord gateway
  task unexpectedly ends, Odin clears readiness and exits with status 1 so the
  process supervisor restarts it, instead of idling HTTP-only.
- **Slash commands are one global set** (`/stop`, `/steer`, `/status`, `/usage`,
  `/reload`) available in guilds and in bot DMs. Legacy per-guild copies are
  cleared at startup; global publication proceeds even if a guild cleanup fails.
- **Scheduler:** pure outbound HTTP webhook actions run without Discord;
  Discord-delivered actions still require a connected gateway.
- **Fresh package installs** start a loopback bootstrap service and complete
  setup in the WebUI (`http://127.0.0.1:<port>/ui/`, or through an SSH tunnel).
- `discord.py` is pinned to 2.7.1.

### Added

- WebUI-first onboarding: transient bootstrap service, installation-bound
  initialization state kept private under `data/initialization/`, and the
  `GET /api/setup/status`, `POST /api/setup/complete` and
  `POST /api/setup/listener` routes with a Setup page.
- Supervised Discord attachment with a connection supervisor and the
  administrator-only `GET`/`POST /api/discord/connection` routes (status,
  connect, detach). See `docs/discord-connection-lifecycle.md`.
- Live **Automatic learning** toggle in Capabilities → Learned.
- Hyprland (Wayland) computer-use foundations: validated compositor
  rediscovery, instance-scoped endpoints, managed plugin activation checks with
  root-required diagnostics, target inventory, quiet focus recovery, immutable
  startup grants, retained release receipts after a lost acknowledgement, and a
  scoped cross-compositor retirement witness. Full task-continuous compositor
  restart recovery is not claimed.
- Computer-use error guidance and local recovery modules with truthful
  `executed` versus `verified` outcomes and cleanup receipts.
- Bounded quiet-process waits: an iteration that only polls `manage_process`
  for 30–120 seconds is exempt from the repetition guard until the job's
  original deadline. See `docs/bounded-process-waits.md`.
- `GET /api/schedules/status`, and channel-less HTTP schedule actions in the API
  and the Schedules page.
- Development verification guide (`docs/testing.md`); parallel test execution
  in CI with `make test` / `make test-cov`.

### Changed

- Discord message sends retry only proven connect-phase connector failures;
  ambiguous transport errors are not replayed, so replies are never duplicated.
- API routes are administrator-only by default except explicit self-service
  routes. Listener widening requires a freshly entered raw admin credential.
  Credential rotation, deletion, demotion or session expiry revokes WebSocket
  authority. Corruption of the dynamic token store denies dynamic credentials
  only; otherwise-valid static credentials keep working and there is never an
  anonymous fallback.
- Computer use on X11: optional session-start fields that are null or blank
  mean absent; lifecycle and action tool descriptions state that a local ledger
  release is not a compositor acknowledgement; a capture failure clears stale
  observations and delivery authority.
- Initialization storage supports existing data layouts with canonical pinning
  of symlinked parents; lock or migration-write failures no longer prevent HTTP
  startup; a verified legacy installation keeps its authenticated API while only
  new durable setup or listener decisions wait for repaired storage.
- Setup changes to timezone, hosts and browser settings report the restart they
  require instead of applying silently.

### Fixed

- Six startup and lifecycle defects introduced during the campaign: a launch
  configuration alias losing workspace protection, a stale ready callback
  reversing a newer disconnect, onboarding credential binding not durable for
  every accepted YAML, setup configuration and runtime consumers disagreeing,
  gateway retirement waiting through reconnect backoff, and overlapping
  scheduled runs leaking reservation metadata.
- Initialization state cache invalidation on completion, bind writes,
  replacement, chmod and deletion; a vanished pending record can no longer
  become a completed legacy install.
- First Discord attach on an unqualified `discord.py` layout now uses the
  public library startup path.
- Post-commit recovery settlement runs outside the rollback handler; weakly held
  per-loop locks keep strong references for active owners; an unreachable setup
  status response and two nonexistent web-config callbacks were removed.
- Hyprland integration repairs: native inventory response fields, selection
  identity and geometry schemas, focus-loss recovery, and the guardian parser.
- Computer use on X11: a stroke batch cut short by the guardian's dispatch
  deadline with a confirmed input release is again recoverable, so Odin
  observes fresh and continues instead of stopping for operator intervention.
  Partial actions stay interrupted and are never replayed; unknown-release,
  ownership, focus and wrong-target failures remain terminal.

### Removed

- `gpt-5.5` and `gpt-5.3-codex-spark` from selectable models and catalogues.
- Learned-context injection by default (now behind the opt-in switch).

### Security

- Loopback-only bootstrap until authenticated listener consent; one-shot admin
  credential for widening, revalidated under the configuration transaction.
- Token store parsing fails closed on corruption without enabling anonymous
  access; computer operator routes revalidate the admin identity after every
  awaited boundary.
