"""Odin — autonomous execution agent on Discord."""

from .version import get_version as _get_version

__version__ = _get_version()
__project__ = "Odin"
